const SITE_HEADER_HTML: string = "<header id=\"siteHeader\">\n  <div class=\"nav-inner\">\n    <a href=\"#top\" class=\"logo\">\n      <span class=\"logo-mark\"><span>OL</span></span>\n      OpsLogic\n    </a>\n    <nav class=\"links\">\n      <a href=\"/about-us\">About Us</a>\n      <a href=\"/success-stories\">Success Stories</a>\n      <a href=\"/services\">Services</a>\n      <a href=\"/careers\">Careers</a>\n      <a href=\"/contact-us\">Contact Us</a>\n    </nav>\n    <a href=\"/contact-us\" class=\"nav-cta magnetic\" data-cursor=\"click\">Let's talk</a>\n  </div>\n</header>";

export default function SiteHeader() {
  return <div dangerouslySetInnerHTML={{ __html: SITE_HEADER_HTML }} />;
}
