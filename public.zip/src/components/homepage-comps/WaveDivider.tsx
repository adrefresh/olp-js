const WAVE_DIVIDER_HTML: string = "<div class=\"wave-divider\" style=\"margin-top:-68px; position:relative; z-index:3;\">\n    <svg viewBox=\"0 0 1440 70\" preserveAspectRatio=\"none\"><path d=\"M0,32 C240,70 480,0 720,20 C960,40 1200,70 1440,24 L1440,70 L0,70 Z\" fill=\"var(--paper)\"/></svg>\n  </div>";

export default function WaveDivider() {
  return <div dangerouslySetInnerHTML={{ __html: WAVE_DIVIDER_HTML }} />;
}
