const CURSOR_FX_HTML: string = "<div class=\"cur-dot\" id=\"curDot\"></div>\n<div class=\"cur-ring\" id=\"curRing\"><span class=\"cur-label\" id=\"curLabel\"></span></div>";

export default function CursorFx() {
  return <div dangerouslySetInnerHTML={{ __html: CURSOR_FX_HTML }} />;
}
