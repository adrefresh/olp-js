const HERO_HTML: string = "<section class=\"hero\"><i class=\"orb\"></i><div class=\"wrap hero-copy reveal\"><span class=\"eyebrow\">Not your usual vendor</span><h1>We make the <em>backstage</em> feel like a superpower.</h1><p>OpsLogic is an operations partner for teams with big plans and zero patience for busywork. We untangle the essentials so ambitious businesses can move with momentum.</p><div class=\"hero-actions\"><a class=\"button\" href=\"#manifesto\">Our manifesto \u2193</a><a class=\"button dark\" href=\"/contact-us\">Meet the team \u2197</a></div></div></section><div class=\"ticker\"><div class=\"ticker-inner\">Build with intent <b>\u2733</b> Think in systems <b>\u2733</b> Make space for growth <b>\u2733</b> Build with intent <b>\u2733</b> Think in systems <b>\u2733</b> Make space for growth <b>\u2733</b></div></div>";

export default function Hero() {
  return <div dangerouslySetInnerHTML={{ __html: HERO_HTML }} />;
}
