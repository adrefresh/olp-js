const LIFEHERE_HTML: string = "<section><div class=\"wrap split\"><div class=\"reveal\"><span class=\"eyebrow\">Life here</span><h2 style=\"margin-top:1rem\">Work with energy, not theatre.</h2><p class=\"muted\">We care about focused work, honest feedback, flexible ways of collaborating and the occasional very passionate debate about fonts.</p></div><div class=\"grid two\"><div class=\"card reveal\"><p class=\"metric\">\u221e</p><h3>room to grow</h3></div><div class=\"card reveal\"><p class=\"metric\">2</p><h3>global hubs</h3></div><div class=\"card reveal\"><p class=\"metric\">1</p><h3>shared mission</h3></div><div class=\"card reveal\"><p class=\"metric\">100%</p><h3>real people</h3></div></div></div></section>";

export default function LifeHere() {
  return <div dangerouslySetInnerHTML={{ __html: LIFEHERE_HTML }} />;
}
