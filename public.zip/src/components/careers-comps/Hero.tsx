const HERO_HTML: string = "<section class=\"hero\"><i class=\"orb\"></i><div class=\"wrap hero-copy reveal\"><span class=\"eyebrow orange\">Careers at OpsLogic</span><h1>Bring your whole <em>brain.</em></h1><p>We are building a team of clear thinkers, kind collaborators and restless improvers. If you like making complex work feel simple, let's make a move.</p><a class=\"button\" href=\"#openings\">See openings \u2193</a></div></section>";

export default function Hero() {
  return <div dangerouslySetInnerHTML={{ __html: HERO_HTML }} />;
}
