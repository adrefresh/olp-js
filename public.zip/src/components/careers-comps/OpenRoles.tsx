const OPENROLES_HTML: string = "<section id=\"openings\" style=\"background:#e9f8ff\"><div class=\"wrap\"><span class=\"eyebrow\">Open roles</span><h2 class=\"reveal\" style=\"margin:1rem 0 2rem\">Find your next good challenge.</h2><div class=\"jobs reveal\"><a class=\"job\" href=\"/contact-us\"><span><b>Talent Acquisition Specialist</b><br><small>Hyderabad \u00b7 Full time \u00b7 People</small></span><b>Apply \u2197</b></a><a class=\"job\" href=\"/contact-us\"><span><b>SAP Functional Consultant</b><br><small>Hybrid \u00b7 Full time \u00b7 Technology</small></span><b>Apply \u2197</b></a><a class=\"job\" href=\"/contact-us\"><span><b>Operations Associate</b><br><small>Hyderabad \u00b7 Full time \u00b7 Operations</small></span><b>Apply \u2197</b></a></div></div></section>";

export default function OpenRoles() {
  return <div dangerouslySetInnerHTML={{ __html: OPENROLES_HTML }} />;
}
