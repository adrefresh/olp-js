const NOFITCTA_HTML: string = "<section><div class=\"wrap card reveal\" style=\"background:#fff0df\"><span class=\"eyebrow orange\">No perfect fit listed?</span><h2 style=\"margin:1rem 0;max-width:14ch\">Make a case for yourself.</h2><p class=\"muted\">Tell us what you do brilliantly and why you want in.</p><a class=\"button dark\" href=\"/contact-us\">Say hello \u2197</a></div></section>";

export default function NoFitCta() {
  return <div dangerouslySetInnerHTML={{ __html: NOFITCTA_HTML }} />;
}
