const VIBECHECK_HTML: string = "<section class=\"dark-zone\"><div class=\"wrap\"><span class=\"eyebrow orange\">Our vibe check</span><div class=\"grid three\" style=\"margin-top:2rem\"><article class=\"card reveal\"><h3>Own the room</h3><p>Have a point of view. Bring receipts. Follow through.</p></article><article class=\"card reveal\"><h3>Stay curious</h3><p>Ask better questions before racing toward an answer.</p></article><article class=\"card reveal\"><h3>Be human</h3><p>Ambition gets better when it comes with generosity.</p></article></div></div></section>";

export default function VibeCheck() {
  return <div dangerouslySetInnerHTML={{ __html: VIBECHECK_HTML }} />;
}
