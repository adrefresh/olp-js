const FAQ_HTML: string = "<section style=\"background:#e9f8ff\"><div class=\"wrap\"><span class=\"eyebrow\">Still curious?</span><h2 class=\"reveal\" style=\"max-width:13ch;margin:1rem 0\">A quick answer before a smart conversation.</h2><div class=\"accordion reveal\"><div class=\"faq\"><button>Can we start with one service? <span>+</span></button><div class=\"answer\">Absolutely. Most relationships begin with one urgent need and grow from there when it makes sense.</div></div><div class=\"faq\"><button>Do you work with distributed teams? <span>+</span></button><div class=\"answer\">Yes. We are built around clear systems and flexible collaboration across locations.</div></div></div></div></section>";

export default function Faq() {
  return <div dangerouslySetInnerHTML={{ __html: FAQ_HTML }} />;
}
