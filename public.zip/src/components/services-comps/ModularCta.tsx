const MODULARCTA_HTML: string = "<section><div class=\"wrap split\"><div class=\"visual reveal\"><span class=\"pill one\">Your team</span><span class=\"pill two\">OpsLogic layer</span><svg viewBox=\"0 0 400 300\"><path d=\"M80 190 C140 70 230 240 320 110\" stroke=\"#0b0c10\" stroke-width=\"8\" fill=\"none\"/><circle cx=\"80\" cy=\"190\" r=\"19\" fill=\"#ff8a1e\"/><circle cx=\"320\" cy=\"110\" r=\"19\" fill=\"#18a7e0\"/></svg></div><div class=\"reveal\"><span class=\"eyebrow\">Not one-size-fits-all</span><h2 style=\"margin-top:1rem\">Mix. Match. Make it yours.</h2><p class=\"muted\">Start with one knot to untangle. Add support as your company grows. Our work is modular by design and always anchored in what matters to you.</p><a class=\"button\" href=\"/contact-us\">Build your support stack \u2197</a></div></div></section>";

export default function ModularCta() {
  return <div dangerouslySetInnerHTML={{ __html: MODULARCTA_HTML }} />;
}
