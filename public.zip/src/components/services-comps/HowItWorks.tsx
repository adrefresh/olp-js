const HOWITWORKS_HTML: string = "<section class=\"dark-zone\"><div class=\"wrap split\"><div class=\"reveal\"><span class=\"eyebrow orange\">How it works</span><h2 style=\"margin-top:1rem\">Big-picture thinking. Tiny-detail energy.</h2></div><div class=\"timeline reveal\"><article><b>01 / Decode</b><p>We listen hard, find the pressure points and define the highest-leverage move.</p></article><article><b>02 / Design</b><p>We build an approach that fits your team\u2014not an off-the-shelf fantasy.</p></article><article><b>03 / Deliver</b><p>We embed, execute and keep improving with you in the room.</p></article></div></div></section>";

export default function HowItWorks() {
  return <div dangerouslySetInnerHTML={{ __html: HOWITWORKS_HTML }} />;
}
