const HERO_HTML: string = "<section class=\"hero\"><i class=\"orb\"></i><div class=\"wrap hero-copy reveal\"><span class=\"eyebrow\">The good stuff</span><h1>Your business, <em>unblocked.</em></h1><p>One sharp, responsive operations partner across the functions that keep your company in motion. Pick a lane\u2014or let us connect the whole map.</p><div class=\"hero-actions\"><a class=\"button\" href=\"#services\">Explore the menu \u2193</a></div></div></section>";

export default function Hero() {
  return <div dangerouslySetInnerHTML={{ __html: HERO_HTML }} />;
}
