const FINALCTA_HTML: string = "<section><div class=\"wrap\"><span class=\"eyebrow\">Your turn</span><h2 class=\"reveal\" style=\"max-width:12ch;margin:1rem 0 2rem\">Let's put your next milestone on the board.</h2><a class=\"button reveal\" href=\"/contact-us\">Start a conversation \u2197</a></div></section>";

export default function FinalCta() {
  return <div dangerouslySetInnerHTML={{ __html: FINALCTA_HTML }} />;
}
