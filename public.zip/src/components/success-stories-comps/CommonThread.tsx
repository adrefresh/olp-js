const COMMONTHREAD_HTML: string = "<section class=\"dark-zone\"><div class=\"wrap split\"><div class=\"reveal\"><span class=\"eyebrow orange\">The common thread</span><h2 style=\"margin-top:1rem\">Every win starts with one honest question.</h2></div><p class=\"quote reveal\">\u201cWhat is getting in the way of your team doing its best work?\u201d</p></div></section>";

export default function CommonThread() {
  return <div dangerouslySetInnerHTML={{ __html: COMMONTHREAD_HTML }} />;
}
