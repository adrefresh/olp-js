const HERO_HTML: string = "<section class=\"hero\"><i class=\"orb\"></i><div class=\"wrap hero-copy reveal\"><span class=\"eyebrow orange\">Proof, not promises</span><h1>Good work makes a <em>ripple.</em></h1><p>See how growth-minded teams replaced operational drag with clearer systems, stronger people and measurable momentum.</p></div></section>";

export default function Hero() {
  return <div dangerouslySetInnerHTML={{ __html: HERO_HTML }} />;
}
