const HERO_HTML: string = "<section class=\"hero\"><i class=\"orb\"></i><div class=\"wrap hero-copy reveal\"><span class=\"eyebrow orange\">A good first move</span><h1>Let's make your <em>next</em> move.</h1><p>Bring us the messy brief, the complicated question or the big idea. We'll bring curiosity, useful perspective and a clear way forward.</p></div></section>";

export default function Hero() {
  return <div dangerouslySetInnerHTML={{ __html: HERO_HTML }} />;
}
