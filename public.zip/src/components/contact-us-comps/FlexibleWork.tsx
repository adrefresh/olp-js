const FLEXIBLEWORK_HTML: string = "<section><div class=\"wrap split\"><div class=\"visual reveal\"><span class=\"pill one\">Hyderabad</span><span class=\"pill two\">Scarborough</span><svg viewBox=\"0 0 400 300\"><path d=\"M76 210C170 50 250 260 332 80\" stroke=\"#18a7e0\" stroke-width=\"4\" stroke-dasharray=\"9 9\" fill=\"none\"/><circle cx=\"76\" cy=\"210\" r=\"20\" fill=\"#ff8a1e\"/><circle cx=\"332\" cy=\"80\" r=\"20\" fill=\"#0b0c10\"/></svg></div><div class=\"reveal\"><span class=\"eyebrow\">Two hubs, wide reach</span><h2 style=\"margin-top:1rem\">Wherever your team works, we can work with it.</h2><p class=\"muted\">Our teams collaborate across borders, time zones and functions\u2014so your operations feel joined-up even when your people are not in the same room.</p></div></div></section>";

export default function FlexibleWork() {
  return <div dangerouslySetInnerHTML={{ __html: FLEXIBLEWORK_HTML }} />;
}
