const TINYFAQ_HTML: string = "<section style=\"background:#fff0df\"><div class=\"wrap\"><span class=\"eyebrow orange\">Tiny FAQ</span><h2 class=\"reveal\" style=\"margin:1rem 0 2rem\">Before you hit send.</h2><div class=\"accordion reveal\"><div class=\"faq\"><button>Do I need a fully formed brief? <span>+</span></button><div class=\"answer\">No. A rough sketch is plenty. We can help turn it into the right question.</div></div><div class=\"faq\"><button>Can you support an existing internal team? <span>+</span></button><div class=\"answer\">Absolutely. We are designed to complement your team, not complicate it.</div></div></div></div></section>";

export default function TinyFaq() {
  return <div dangerouslySetInnerHTML={{ __html: TINYFAQ_HTML }} />;
}
