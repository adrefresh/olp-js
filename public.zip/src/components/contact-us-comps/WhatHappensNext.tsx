const WHATHAPPENSNEXT_HTML: string = "<section class=\"dark-zone\"><div class=\"wrap\"><span class=\"eyebrow orange\">What happens next</span><div class=\"grid three\" style=\"margin-top:2rem\"><article class=\"card reveal\"><span class=\"number\">01 / READ</span><h3>We get the context</h3><p>A real human reads the brief and finds the right person to respond.</p></article><article class=\"card reveal\"><span class=\"number\">02 / TALK</span><h3>We ask the good questions</h3><p>A focused first conversation, with no jargon and no sales theatre.</p></article><article class=\"card reveal\"><span class=\"number\">03 / MAP</span><h3>We chart the move</h3><p>If there is a fit, we make a simple, practical plan together.</p></article></div></div></section>";

export default function WhatHappensNext() {
  return <div dangerouslySetInnerHTML={{ __html: WHATHAPPENSNEXT_HTML }} />;
}
