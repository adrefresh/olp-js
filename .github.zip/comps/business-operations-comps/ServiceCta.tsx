export default function ServiceCta() {
  return (
  <section className="service-cta">
    <div className="wrap">
      <span className="eyebrow">Next move</span>
      <h2>See how we can strengthen your operations.</h2>
      <a className="button" href="/contact-us">Start a conversation ↗</a>
    </div>
  </section>
  );
}
